import knapsackvolatility 
from ortoolpy import knapsack


def knack():
	size = [21, 11, 15, 9, 34, 25, 41, 52]
	weight = [22, 12, 16, 10, 35, 26, 42, 53]
	capacity = 100

	print(knapsack(size, weight, capacity))


if __name__ == '__main__':
	knack()
	knapsackvolatility.swingtrading()


